package com.slocyn.ai

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.AlarmClock
import android.provider.Settings
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.widget.*
import androidx.activity.ComponentActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import java.util.Locale

class MainActivity : ComponentActivity(), TextToSpeech.OnInitListener {
    private lateinit var prefs: SharedPreferences
    private lateinit var logView: TextView
    private lateinit var input: EditText
    private lateinit var tts: TextToSpeech
    private val audioRequest = 701
    private val notificationRequest = 702

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences("wife_ai", MODE_PRIVATE)
        tts = TextToSpeech(this, this)
        buildUi()
        append("WIFE AI is ready. Try: open YouTube, open Settings, set alarm for 7, or remember I like gaming.")
    }

    override fun onResume() {
        super.onResume()
        // If the user revoked microphone permission, stop background mode.
        if (::prefs.isInitialized &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            stopAssistantService()
        }
        updateBackgroundStatus()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(22, 20, 22, 16)
            setBackgroundColor(0xFF101014.toInt())
        }
        val title = TextView(this).apply {
            text = "WIFE AI"
            textSize = 30f
            gravity = Gravity.CENTER
            setTextColor(0xFFFF405A.toInt())
        }
        val subtitle = TextView(this).apply {
            text = "PERSONAL ASSISTANT • ONLINE + OFFLINE"
            textSize = 11f
            gravity = Gravity.CENTER
            setTextColor(0xFFB9B9C5.toInt())
        }
        logView = TextView(this).apply {
            textSize = 15f
            setTextColor(0xFFF3F3F6.toInt())
            setPadding(14, 14, 14, 14)
        }
        val scroll = ScrollView(this).apply {
            addView(logView)
            setBackgroundColor(0xFF1B1B23.toInt())
        }
        input = EditText(this).apply {
            hint = "Type a command…"
            setHintTextColor(0xFF888895.toInt())
            setTextColor(0xFFFFFFFF.toInt())
        }

        root.addView(title)
        root.addView(subtitle)
        root.addView(space(10))
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(input)
        root.addView(button("Send / Run") {
            val command = input.text.toString().trim()
            input.setText("")
            if (command.isNotBlank()) handleCommand(command)
        })
        root.addView(button("🎙 Speak a command") { startVoice() })
        root.addView(button("Enable background mode") { enableBackgroundMode() })
        root.addView(button("Turn background mode OFF") { stopAssistantService(); append("Background mode stopped.") })
        root.addView(button("Open Android app permissions") {
            startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
        })
        root.addView(button("Clear saved memory") {
            prefs.edit().remove("memory").apply()
            append("Saved memory cleared.")
        })
        setContentView(root)
    }

    private fun space(height: Int) = android.view.View(this).apply {
        layoutParams = LinearLayout.LayoutParams(1, height)
    }

    private fun button(label: String, action: () -> Unit) = Button(this).apply {
        text = label
        setOnClickListener { action() }
    }

    private fun append(message: String) {
        if (!::logView.isInitialized) return
        logView.append("\n\n$message")
    }

    private fun updateBackgroundStatus() {
        if (::logView.isInitialized) {
            val on = prefs.getBoolean("background_on", false)
            // Status reflects the user's last chosen setting; Android notification shows actual foreground state.
            logView.append("\n\nBackground mode preference: " + if (on) "ON" else "OFF")
        }
    }

    private fun enableBackgroundMode() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.RECORD_AUDIO), audioRequest)
            append("Allow microphone permission, then press Enable background mode again.")
            return
        }
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), notificationRequest)
            append("Allow notifications, then press Enable background mode again.")
            return
        }
        try {
            val intent = Intent(this, AssistantService::class.java)
            ContextCompat.startForegroundService(this, intent)
            prefs.edit().putBoolean("background_on", true).apply()
            append("Background mode enabled. A persistent notification should appear. Use its Stop button or the OFF button to stop it.")
        } catch (e: Exception) {
            append("Could not enable background mode: ${e.message ?: "Android blocked the request"}. Open app permissions and try again.")
        }
    }

    private fun stopAssistantService() {
        try { stopService(Intent(this, AssistantService::class.java)) } catch (_: Exception) {}
        prefs.edit().putBoolean("background_on", false).apply()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == audioRequest) {
            append(if (grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED)
                "Microphone permission granted. Press Enable background mode again."
            else "Microphone permission denied. Background mode stays off.")
        } else if (requestCode == notificationRequest) {
            append("Notification permission result received. Press Enable background mode again.")
        }
    }

    private fun startVoice() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.RECORD_AUDIO), audioRequest)
            return
        }
        if (!android.speech.SpeechRecognizer.isRecognitionAvailable(this)) {
            append("Speech recognition is not available on this device. You can still type commands.")
            return
        }
        try {
            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault())
                putExtra(RecognizerIntent.EXTRA_PROMPT, "Speak to WIFE AI")
            }
            startActivityForResult(intent, 703)
        } catch (e: Exception) {
            append("Voice input could not start: ${e.message}")
        }
    }

    @Deprecated("Use Activity Result APIs in a future update")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 703 && resultCode == Activity.RESULT_OK) {
            val spoken = data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
            if (!spoken.isNullOrBlank()) {
                append("You said: $spoken")
                handleCommand(spoken)
            }
        }
    }

    private fun handleCommand(raw: String) {
        val command = raw.trim()
        val lower = command.lowercase(Locale.ROOT)
        when {
            lower.startsWith("open ") -> {
                val appName = lower.removePrefix("open ").trim()
                val packageName = when {
                    "youtube" in appName -> "com.google.android.youtube"
                    "whatsapp" in appName -> "com.whatsapp"
                    "settings" in appName -> null
                    "chrome" in appName -> "com.android.chrome"
                    else -> null
                }
                try {
                    val intent = if (appName == "settings") Intent(Settings.ACTION_SETTINGS)
                    else packageName?.let { this.packageManager.getLaunchIntentForPackage(it) }
                    if (intent != null) {
                        startActivity(intent)
                        append("Opening $appName.")
                    } else append("I couldn't find that app. This starter supports YouTube, WhatsApp, Chrome, and Settings.")
                } catch (e: Exception) { append("Could not open app: ${e.message}") }
            }
            lower.startsWith("set alarm") -> {
                try {
                    val hour = Regex("""\b(\d{1,2})\b""").find(lower)?.groupValues?.get(1)?.toInt() ?: 7
                    if (hour !in 0..23) { append("Use a 24-hour hour from 0 to 23."); return }
                    val intent = Intent(AlarmClock.ACTION_SET_ALARM).apply {
                        putExtra(AlarmClock.EXTRA_HOUR, hour)
                        putExtra(AlarmClock.EXTRA_MINUTES, 0)
                        putExtra(AlarmClock.EXTRA_MESSAGE, "WIFE AI alarm")
                        putExtra(AlarmClock.EXTRA_SKIP_UI, false)
                    }
                    startActivity(intent)
                    append("Opening the alarm screen for $hour:00. Confirm it in your Clock app.")
                } catch (e: Exception) { append("Couldn't open the alarm screen: ${e.message}") }
            }
            lower.startsWith("remember ") -> {
                val newMemory = command.removePrefix("remember ").trim()
                if (newMemory.isNotBlank()) {
                    prefs.edit().putString("memory", newMemory).apply()
                    append("I'll save this preference on this phone: $newMemory")
                }
            }
            lower == "show memory" -> append("Saved memory: ${prefs.getString("memory", "Nothing saved")}")
            lower.startsWith("search ") -> {
                val query = command.removePrefix("search ").trim()
                startActivity(Intent(Intent.ACTION_WEB_SEARCH).putExtra("query", query))
                append("Opening web search for: $query")
            }
            else -> {
                val endpoint = prefs.getString("endpoint", "")?.trim().orEmpty()
                if (endpoint.startsWith("https://")) {
                    append("Online AI backend is not connected in this starter yet. Add your backend integration in the next step.")
                } else {
                    append("Offline starter mode: I can open selected apps, set an alarm, search the web, and save a short memory. For full AI chat, connect a secure HTTPS AI backend.")
                    if (ttsReady) tts.speak("I can help with simple phone commands. Connect an AI backend for full chat.", TextToSpeech.QUEUE_FLUSH, null, "wife-reply")
                }
            }
        }
    }

    private var ttsReady = false
    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            tts.language = Locale.getDefault()
            ttsReady = true
        }
    }

    override fun onDestroy() {
        if (::tts.isInitialized) tts.shutdown()
        super.onDestroy()
    }
}
