# WIFE AI — Android starter

This is a first Android Studio project for WIFE AI, an online/offline personal assistant prototype.

## Features in this starter
- Text commands and one-shot speech input using Android speech recognition
- Open YouTube, WhatsApp, Chrome, and Android Settings
- Open the alarm UI and ask the user to confirm the alarm
- Save one short local preference and clear it
- User-controlled foreground background mode with a persistent notification and Stop action
- Basic offline fallback responses and Android text-to-speech

## Important background-mode behavior
Background mode is started only after the user taps **Enable background mode** and grants the microphone permission. It displays an ongoing notification with a Stop action. This starter does not continuously record or secretly listen. If microphone permission is revoked, the app stops the service the next time the app resumes; Android may also stop it according to OS policies. Do not assume that revoking permission instantly broadcasts an app callback in every Android version.

## Build APK
1. Install Android Studio on a computer.
2. Open this folder as a project.
3. Let Gradle sync. Use JDK 17.
4. Build > Build Bundle(s) / APK(s) > Build APK(s).
5. For a debug APK, Android Studio usually writes it to `app/build/outputs/apk/debug/app-debug.apk`.

This environment has created the source project but has not built or verified an APK. You need Android Studio/Gradle to compile it.

## Online AI
The UI is prepared for a backend integration, but a real AI endpoint is not implemented yet. Do not put a private API key inside the APK. The next version should use a small HTTPS backend that holds the key securely, then the Android app sends chat messages to that backend.

## Android limitations
No app can gain unrestricted access to every phone feature. Calls, SMS, other apps' private data, protected settings, and continuous background microphone access have Android restrictions and may need additional special permissions, user actions, or policy review.
