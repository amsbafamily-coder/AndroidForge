# WIFE AI — Android starter project

## Important
This download is the Android Studio **source project**, not an installable APK.
An APK has not been built or tested in this environment. Android Studio is needed to compile it.

## Current starter features
- Bengali voice input through Android speech recognition (device/service support may vary)
- Bengali text-to-speech where the phone has a Bengali voice installed
- Basic typed commands and voice commands
- Open supported apps such as YouTube, WhatsApp, Chrome, and Android Settings
- Open a web search and request an alarm using Android intents
- Save/clear a simple local memory note
- User-controlled foreground/background service with a visible notification and stop action

## Not yet included
- A full online conversational AI backend. For AI answers, a secure backend and API credentials are needed.
- Full unrestricted phone control. Android protects calls, messages, camera, contacts, and other sensitive actions behind permissions and system confirmation.
- Guaranteed always-on listening. This starter does not continuously record audio in the background.
- A ready-to-install APK.

## Build an APK
1. On a computer, install Android Studio.
2. Extract this ZIP.
3. In Android Studio choose **Open** and select the `WIFE_AI_Android_Project` folder.
4. Let Gradle sync finish.
5. Use **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
6. Android Studio will show the APK output location. Transfer it to your phone and install it, allowing installs from that source if Android asks.

## If you only have an Android phone
This source ZIP cannot be installed directly with ZArchiver. ZArchiver only extracts files; it does not compile Android projects. You would need an Android-compatible build environment or a computer to build the APK.

## Design
The `design/WIFE_AI_Anime_Design.png` file is a concept image for the app's visual direction. It is not automatically installed as the Android launcher icon.
